package com.app.videoeditor

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd

class MainActivity : AppCompatActivity(), InterstitialCallBack {

    private val TAG = "MainActivity"
    private val adUnit = "your_ad_unit_id" // Replace with your AdMob ad unit ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Example of when to load and show ad
        loadAndShowAd()
    }

    private fun loadAndShowAd() {
        val isAppPurchased = false // Check if the app is purchased (e.g., via in-app purchase)
        val isInternetConnected = true // Check if the device has an internet connection
        val remoteConfig = true // Check remote configuration if needed

        val interstitialAds = InterstitialAds(this)

        interstitialAds.loadAndShow(
            adUnit = adUnit,
            isAppPurchased = isAppPurchased,
            isInternetConnected = isInternetConnected,
            remoteConfig = remoteConfig,
            loadingMessage = "Loading Ad...",
            callBack = this // Setting the current activity as the callback
        )
    }

    // InterstitialCallBack methods for handling ad events
    override fun onAdLoaded() {
        Log.d(TAG, "Ad Loaded")
        Toast.makeText(this, "Ad Loaded", Toast.LENGTH_SHORT).show()
    }

    override fun onAdNotReadyYet() {
        Log.d(TAG, "Ad is not ready yet")
        Toast.makeText(this, "Ad is not ready", Toast.LENGTH_SHORT).show()
    }

    override fun onAdFailedToLoad(adError: LoadAdError) {
        Log.d(TAG, "Ad Failed to Load: ${adError.message}")
        Toast.makeText(this, "Failed to load ad", Toast.LENGTH_SHORT).show()
    }

    override fun onAdDismissed() {
        Log.d(TAG, "Ad Dismissed")
        Toast.makeText(this, "Ad Dismissed", Toast.LENGTH_SHORT).show()
    }

    override fun onAdFailedToShow(adError: AdError) {
        Log.d(TAG, "Ad Failed to Show: ${adError.message}")
        Toast.makeText(this, "Failed to show ad", Toast.LENGTH_SHORT).show()
    }

    override fun onAdShowed() {
        Log.d(TAG, "Ad Showed")
        Toast.makeText(this, "Ad Showed", Toast.LENGTH_SHORT).show()
    }

    override fun onAdImpression() {
        Log.d(TAG, "Ad Impression")
    }

    override fun onAdClicked() {
        Log.d(TAG, "Ad Clicked")
    }

    // Implement the missing abstract method from InterstitialCallBack
    override fun onAppPurchased() {
        // Handle app purchased scenario here, maybe skip ads or show a thank you message
        Log.d(TAG, "App has been purchased, skipping ad.")
        Toast.makeText(this, "App Purchased - No Ads", Toast.LENGTH_SHORT).show()
    }

    // Implement the missing abstract method from InterstitialCallBack
    override fun onError(error: String) {
        // Handle the error scenario here
        Log.d(TAG, "Error occurred: $error")
        Toast.makeText(this, "Error: $error", Toast.LENGTH_SHORT).show()
    }

    // A simple function to simulate the app's purchase state (optional)
    private fun checkAppPurchaseStatus(): Boolean {
        // Here, you can check if the user has purchased the app or not (e.g., using in-app purchases).
        return false
    }

    // This is an example of a method to simulate internet connection checking (optional)
    private fun checkInternetConnection(): Boolean {
        // Here, you can check the device's internet connection status.
        return true
    }

    // Simulating a remote config check (optional)
    private fun checkRemoteConfig(): Boolean {
        // Implement your remote configuration checking here if needed.
        return true
    }
}
