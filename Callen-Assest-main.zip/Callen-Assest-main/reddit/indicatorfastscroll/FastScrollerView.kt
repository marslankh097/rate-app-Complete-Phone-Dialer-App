package com.reddit.indicatorfastscroll

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.ColorStateList
import android.os.Build
import android.util.AttributeSet
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.res.getColorStateListOrThrow
import androidx.core.content.res.getDimensionOrThrow
import androidx.core.content.res.getDimensionPixelSizeOrThrow
import androidx.core.content.res.getResourceIdOrThrow
import androidx.core.content.res.use
import androidx.core.view.children
import androidx.core.view.updateLayoutParams
import androidx.core.view.updatePadding
import androidx.core.widget.TextViewCompat
import androidx.recyclerview.widget.RecyclerView
import com.phonecontactscall.contectapp.phonedialerr.R
import kotlin.math.min

typealias ItemIndicatorWithPosition = Pair<FastScrollItemIndicator, Int>


class FastScrollerView @JvmOverloads constructor(
  context: Context,
  attrs: AttributeSet? = null,
  defStyleAttr: Int = R.attr.indicatorFastScrollerStyle,
  defStyleRes: Int = R.style.Widget_IndicatorFastScroll_FastScroller
) : LinearLayout(
  context,
  attrs,
  defStyleAttr,
  defStyleRes
) {

  var iconSize: Int = 0
    set(value) {
      field = value
      bindItemIndicatorViews()
    }
  var iconColor: ColorStateList? = null
    set(value) {
      field = value
      pressedIconColor = value?.getColorForState(intArrayOf(android.R.attr.state_activated))
      bindItemIndicatorViews()
    }
  var textAppearanceRes: Int = 0
    set(value) {
      field = value
      bindItemIndicatorViews()
    }
  var textColor: ColorStateList? = null
    set(value) {
      field = value
      pressedTextColor = value?.getColorForState(intArrayOf(android.R.attr.state_activated))
      bindItemIndicatorViews()
    }
  var textPadding: Float = 0f
    set(value) {
      field = value
      bindItemIndicatorViews()
    }

  private var pressedIconColor: Int? = null
  private var pressedTextColor: Int? = null

  internal var itemIndicatorsBuilder: ItemIndicatorsBuilder = ItemIndicatorsBuilder()

  val itemIndicatorSelectedCallbacks: MutableList<ItemIndicatorSelectedCallback> = ArrayList()

  internal var onItemIndicatorTouched: ((Boolean) -> Unit)? = null

  private val isSetup: Boolean get() = (recyclerView != null)
  private var recyclerView: RecyclerView? = null
  private var adapter: RecyclerView.Adapter<*>? = null
    set(value) {
      field?.unregisterAdapterDataObserver(adapterDataObserver)
      field = value
      value?.let { newAdapter ->
        newAdapter.registerAdapterDataObserver(adapterDataObserver)
        postUpdateItemIndicators()
      }
    }
  private val adapterDataObserver: RecyclerView.AdapterDataObserver = createAdapterDataObserver()
  private lateinit var getItemIndicator: (Int) -> FastScrollItemIndicator?

  var showIndicator: ((FastScrollItemIndicator, Int, Int) -> Boolean)? by onUpdate { _ ->
    postUpdateItemIndicators()
  }

  var useDefaultScroller: Boolean = true
  private var lastSelectedPosition: Int? = null
  private var isUpdateItemIndicatorsPosted = false

  private val itemIndicatorsWithPositions: MutableList<ItemIndicatorWithPosition> = ArrayList()

  val itemIndicators: List<FastScrollItemIndicator>
    get() = itemIndicatorsWithPositions.map(ItemIndicatorWithPosition::first)

  init {
    context.theme.obtainStyledAttributes(
      attrs,
      R.styleable.FastScrollerView,
      defStyleAttr,
      defStyleRes
    ).use { attrsArray ->
      throwIfMissingAttrs(styleRes = R.style.Widget_IndicatorFastScroll_FastScroller) {
        iconSize = attrsArray.getDimensionPixelSizeOrThrow(R.styleable.FastScrollerView_fastScrollerIconSize)
        iconColor = attrsArray.getColorStateListOrThrow(R.styleable.FastScrollerView_fastScrollerIconColor)
        textAppearanceRes = attrsArray.getResourceIdOrThrow(
          R.styleable.FastScrollerView_android_textAppearance
        )
        textColor = attrsArray
          .getColorStateListOrThrow(R.styleable.FastScrollerView_android_textColor)
        textPadding = attrsArray.getDimensionOrThrow(R.styleable.FastScrollerView_fastScrollerTextPadding)
      }
    }

    isFocusableInTouchMode = true
    isClickable = true
    orientation = VERTICAL
    gravity = Gravity.CENTER

    if (isInEditMode) {
      itemIndicatorsWithPositions += listOf(
        ItemIndicatorWithPosition(FastScrollItemIndicator.Text("A"), 0),
        ItemIndicatorWithPosition(FastScrollItemIndicator.Text("B"), 1),
        ItemIndicatorWithPosition(FastScrollItemIndicator.Text("C"), 2),
        ItemIndicatorWithPosition(FastScrollItemIndicator.Text("D"), 3),
        ItemIndicatorWithPosition(FastScrollItemIndicator.Text("E"), 4)
      )
      bindItemIndicatorViews()
    }
  }


  @JvmOverloads
  fun setupWithRecyclerView(
    recyclerView: RecyclerView,
    getItemIndicator: (Int) -> FastScrollItemIndicator?,
    showIndicator: ((FastScrollItemIndicator, Int, Int) -> Boolean)? = null,
    useDefaultScroller: Boolean = true
  ) {
    check(!isSetup) { "Only set this view's RecyclerView once!" }
    this.recyclerView = recyclerView
    this.getItemIndicator = getItemIndicator
    this.showIndicator = showIndicator
    this.useDefaultScroller = useDefaultScroller

    this.adapter = recyclerView.adapter.also {
      if (it != null) {
        updateItemIndicators()
      }
    }
    recyclerView.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
      if (recyclerView.adapter !== adapter) {
        this@FastScrollerView.adapter = recyclerView.adapter
      }
    }
  }

  private fun postUpdateItemIndicators() {
    if (!isUpdateItemIndicatorsPosted) {
      isUpdateItemIndicatorsPosted = true
      post {
        if (recyclerView!!.run { isAttachedToWindow && adapter != null }) {
          updateItemIndicators()
        }
        isUpdateItemIndicatorsPosted = false
      }
    }
  }

  private fun updateItemIndicators() {
    itemIndicatorsWithPositions.clear()
    itemIndicatorsBuilder
      .buildItemIndicators(recyclerView!!, getItemIndicator, showIndicator)
      .toCollection(itemIndicatorsWithPositions)

    bindItemIndicatorViews()
  }

  private fun bindItemIndicatorViews() {
    removeAllViews()

    if (itemIndicatorsWithPositions.isEmpty()) {
      return
    }

    fun createIconView(iconIndicator: FastScrollItemIndicator.Icon): ImageView =
      (LayoutInflater.from(context).inflate(
        R.layout.fast_scroller_indicator_icon, this, false
      ) as ImageView).apply {
        updateLayoutParams {
          width = iconSize
          height = iconSize
        }
        iconColor?.let(::setImageTintList)
        setImageResource(iconIndicator.iconRes)
        tag = iconIndicator
      }

    fun createTextView(textIndicators: List<FastScrollItemIndicator.Text>): TextView =
      (LayoutInflater.from(context).inflate(
        R.layout.fast_scroller_indicator_text, this, false
      ) as TextView).apply {
        TextViewCompat.setTextAppearance(this, textAppearanceRes)
        textColor?.let(::setTextColor)
        updatePadding(top = textPadding.toInt(), bottom = textPadding.toInt())
        setLineSpacing(textPadding, lineSpacingMultiplier)
        text = textIndicators.joinToString(separator = "\n") { it.text }
        tag = textIndicators
      }

    val views = ArrayList<View>()
    itemIndicators.run {
      var index = 0
      while (index <= lastIndex) {
        @Suppress("UNCHECKED_CAST")
        val textIndicatorsBatch = subList(index, size)
          .takeWhile { it is FastScrollItemIndicator.Text }
          as List<FastScrollItemIndicator.Text>
        if (textIndicatorsBatch.isNotEmpty()) {
          views.add(createTextView(textIndicatorsBatch))
          index += textIndicatorsBatch.size
        } else {
          when (val indicator = this[index]) {
            is FastScrollItemIndicator.Icon -> {
              views.add(createIconView(indicator))
            }
            is FastScrollItemIndicator.Text -> {
              throw IllegalStateException("Text indicator wasn't batched")
            }
          }
          index++
        }
      }
    }
    views.forEach(::addView)
  }

  private fun selectItemIndicator(
    indicator: FastScrollItemIndicator,
    indicatorCenterY: Int,
    touchedView: View,
    textLine: Int?
  ) {
    val position = itemIndicatorsWithPositions
      .first { it.first == indicator }
      .let(ItemIndicatorWithPosition::second)
    if (position != lastSelectedPosition) {
      clearSelectedItemIndicator()
      lastSelectedPosition = position
      if (useDefaultScroller) {
        scrollToPosition(position)
      }
      performHapticFeedback(
        if (Build.VERSION.SDK_INT >= 27) {
          HapticFeedbackConstants.TEXT_HANDLE_MOVE
        } else {
          HapticFeedbackConstants.KEYBOARD_TAP
        }
      )
      if (touchedView is ImageView) {
        touchedView.isActivated = true
      } else if (textLine != null) {
        pressedTextColor?.let { color ->
          TextColorUtil.highlightAtIndex(touchedView as TextView, textLine, color)
        }
      }
      itemIndicatorSelectedCallbacks.forEach {
        it.onItemIndicatorSelected(indicator, indicatorCenterY, position)
      }
    }
  }

  private fun clearSelectedItemIndicator() {
    lastSelectedPosition = null
    if (pressedIconColor != null) {
      children.filterIsInstance<ImageView>().forEach { it.isActivated = false }
    }
    if (pressedTextColor != null) {
      children.filterIsInstance<TextView>().forEach(TextColorUtil::clearHighlight)
    }
  }

  private fun scrollToPosition(position: Int) {
    recyclerView!!.apply {
      stopScroll()
      smoothScrollToPosition(position)
    }
  }

  @SuppressLint("ClickableViewAccessibility")
  override fun onTouchEvent(event: MotionEvent): Boolean {
    fun View.containsY(y: Int) = y in (top until bottom)

    if (event.actionMasked in MOTIONEVENT_STOP_ACTIONS) {
      isPressed = false
      clearSelectedItemIndicator()
      onItemIndicatorTouched?.invoke(false)
      return false
    }

    var consumed = false
    val touchY = event.y.toInt()
    children.forEach { view ->
      if (view.containsY(touchY)) {
        when (view) {
          is ImageView -> {
            val touchedIndicator = view.tag as FastScrollItemIndicator.Icon
            val centerY = view.y.toInt() + (view.height / 2)
            selectItemIndicator(touchedIndicator, centerY, view, textLine = null)
            consumed = true
          }
          is TextView -> {
            @Suppress("UNCHECKED_CAST")
            val possibleTouchedIndicators = view.tag as List<FastScrollItemIndicator.Text>
            val textIndicatorsTouchY = touchY - view.top
            val textLineHeight = view.height / possibleTouchedIndicators.size
            val touchedIndicatorIndex = min(
              textIndicatorsTouchY / textLineHeight,
              possibleTouchedIndicators.lastIndex
            )
            val touchedIndicator = possibleTouchedIndicators[touchedIndicatorIndex]

            val centerY = view.y.toInt() +
              (textLineHeight / 2) + (touchedIndicatorIndex * textLineHeight)
            selectItemIndicator(touchedIndicator, centerY, view, textLine = touchedIndicatorIndex)
            consumed = true
          }
        }
      }
    }

    isPressed = consumed

    onItemIndicatorTouched?.invoke(consumed)
    return consumed
  }

  companion object {

    private val MOTIONEVENT_STOP_ACTIONS = intArrayOf(
      MotionEvent.ACTION_UP,
      MotionEvent.ACTION_CANCEL
    )

    private fun FastScrollerView.createAdapterDataObserver(): RecyclerView.AdapterDataObserver {
      return object : RecyclerView.AdapterDataObserver() {
        override fun onChanged() {
          postUpdateItemIndicators()
        }

        override fun onItemRangeChanged(positionStart: Int, itemCount: Int, payload: Any?) =
          onChanged()

        override fun onItemRangeInserted(positionStart: Int, itemCount: Int) =
          onChanged()

        override fun onItemRangeMoved(fromPosition: Int, toPosition: Int, itemCount: Int) =
          onChanged()

        override fun onItemRangeRemoved(positionStart: Int, itemCount: Int) =
          onChanged()
      }
    }
  }

  interface ItemIndicatorSelectedCallback {
    fun onItemIndicatorSelected(
      indicator: FastScrollItemIndicator,
      indicatorCenterY: Int,
      itemPosition: Int
    )
  }
}
